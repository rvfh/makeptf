// preprocessed version of 'boost/mpl/meta_fun.hpp' header
// see the original for copyright information

